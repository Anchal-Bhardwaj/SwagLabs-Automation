package org.example;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
public class demo {
    public static void main(String[] args) throws InterruptedException {
        WebDriver driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https://www.flipkart.com/account/login");
        WebElement login =driver.findElement(By.xpath("//input[@class='_2IX_2- VJZDxU']"));
        login.sendKeys("1234567890");
        driver.findElement(By.xpath("//button[@class='_2KpZ6l _2HKlqd _3AWRsL']")).click();
        WebElement errorMessage = driver.findElement(By.xpath("//span[contains(text(),'Please enter valid Email ID/Mobile number')]"));
        if (errorMessage.isDisplayed()) {
            System.out.println("Invalid login credentials. Login failed.");
        } else {
            System.out.println("Login successful.");
        }


    }
}

