package org.example;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class LoginLocked {
    public static void main(String[] args) throws InterruptedException{
        WebDriver driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https://www.saucedemo.com/");
        driver.findElement(By.xpath("//input[@id='user-name']")).sendKeys("locked_out_user");
        driver.findElement(By.xpath("//input[@id='password']")).sendKeys("secret_sauce");
        driver.findElement(By.xpath("//input[@id='login-button']")).click();
        Thread.sleep(5000);
        WebElement errorMessage = driver.findElement(By.xpath("(//h3[contains(text(),'Epic sadface: Sorry, this user has been locked out')])[1]"));
        if (errorMessage.isDisplayed()) {
            System.out.println("Sorry, this user has been locked out. Login failed.");
        } else {
            System.out.println("Login successful.");
        }



    }
}

